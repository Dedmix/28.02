﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Chernovik
{
    /// <summary>
    /// Логика взаимодействия для MaterialsPage.xaml
    /// </summary>
    public partial class MaterialsPage : Page
    {
        public MaterialsPage()
        {
            InitializeComponent();
            BuildMaterials(0);

            
        }
        void BuildMaterials(int page)
        {
            Database.user_01Entities Connection = new Database.user_01Entities();

            var list = Connection.Material.OrderBy(m => m.Name).ToList();



            Materiallist.Children.Clear();


            int pages = page * 3;
            for (int i = pages; i < pages + 3; i++)
            {

                Border border = new Border();
                border.Margin = new Thickness(20, 10, 20, 10);
                border.BorderThickness = new Thickness(1);
                border.BorderBrush = Brushes.Orange;

                StackPanel stack1 = new StackPanel();
                stack1.Orientation = Orientation.Horizontal;
                stack1.Margin = new Thickness(10);

                Materiallist.Children.Add(border);
                border.Child = stack1;

                Image img = new Image();
                img.Width = 100;
                img.Margin = new Thickness(5, 5, 5, 5);
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                if (list[i].Image == null)
                {
                    bitmap.UriSource = new Uri("/materials/picture.png", UriKind.Relative);
                }
                else
                {
                    bitmap.UriSource = new Uri(list[i].Image, UriKind.Relative);
                }
                bitmap.EndInit();
                img.Source = bitmap;

                stack1.Children.Add(img);

                StackPanel stack2 = new StackPanel();
                stack1.Children.Add(stack2);
                stack2.Orientation = Orientation.Vertical;
                stack2.Width = 400;
                TextBlock block1 = new TextBlock();
                block1.TextWrapping = TextWrapping.Wrap;
                block1.FontFamily = new FontFamily("Segoe Print");
                block1.FontSize = 16;
                block1.Margin = new Thickness(10, 0, 0, 0);
                block1.Text = list[i].Type + " | " + list[i].Name;
                stack2.Children.Add(block1);

                TextBlock block2 = new TextBlock();
                block2.TextWrapping = TextWrapping.Wrap;
                block2.FontFamily = new FontFamily("Segoe Print");
                block2.FontSize = 14;
                block2.Margin = new Thickness(10, 0, 0, 0);
                block2.Text = "Минимальное количество: " + list[i].MinCount + " шт.";
                stack2.Children.Add(block2);

                var providers = list[i].Provider.ToList();
                string a = " ";
                foreach (var p in providers)
                {
                    a += p.Name + ", ";
                }
                if (a.Length > 2)
                {
                    a=a.Substring(0, a.Length - 2);
                }
                TextBlock block3 = new TextBlock();
                block3.TextWrapping = TextWrapping.Wrap;
                block3.FontFamily = new FontFamily("Segoe Print");
                block3.FontSize = 14;
                block3.Margin = new Thickness(10, 0, 0, 0);
                block3.Text = "Поставщики: "+a;
                stack2.Children.Add(block3);

                Label label = new Label();
                label.Content = "Остаток " + list[i].Count + " " + list[i].Unit + "𝆹";
                label.FontSize = 11;
                label.FontFamily = new FontFamily("Segoe Print");
                stack1.Children.Add(label);


                int countPage = list.Count / 3;
                BuildPagination(countPage, page);
            }


        }
        void BuildPagination(int coint, int activePage)
        {
            Pagination.Children.Clear();
            Pagination.Children.Add(createTextBlock("<", false));
            for (int i = coint; i > 0; i--)
            {
                Pagination.Children.Add(createTextBlock("" + i, i == activePage));
            }
            Pagination.Children.Add(createTextBlock(">", false));
        }
        private TextBlock createTextBlock(string text, bool underline)
        {
            TextBlock textBlock = new TextBlock();
            textBlock.FontSize = 14;
            textBlock.FontFamily = new FontFamily("Segoe Print");
            textBlock.Text = text;
            textBlock.Margin=new Thickness(2,5,2,5);
            if(underline==true)
            {
                textBlock.TextDecorations.Add(TextDecorations.Underline);
            }
            else
            {
                textBlock.Cursor = Cursors.Hand;
                textBlock.MouseLeftButtonDown += onChangePage;
            }
            return textBlock;
        }
        private void onChangePage(object sender, MouseButtonEventArgs e)
        {
            var textBlock = sender as TextBlock;
            if (textBlock != null)
            {
                try
                {
                    int page =int.Parse(textBlock.Text);
                    BuildMaterials(page);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }   
                
            }
        }
    }
}
