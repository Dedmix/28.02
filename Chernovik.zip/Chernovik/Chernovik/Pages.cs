﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chernovik
{
    internal class Pages
    {
        MaterialsPage Material = new MaterialsPage();
    }
}
